package neutrals;

public class BugNav {

}
