package team184;

import battlecode.common.RobotController;

public class Combat extends BaseRobot{

	public Combat(RobotController rc) {
		super(rc);
		// TODO Auto-generated constructor stub
	}

}
