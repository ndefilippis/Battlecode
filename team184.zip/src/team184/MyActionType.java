package team184;
import battlecode.common.*;

public enum MyActionType {
	MOVE,
	DIG,
	YIELD,
}
