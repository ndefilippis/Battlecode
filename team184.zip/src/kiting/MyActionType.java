package kiting;
import battlecode.common.*;

public enum MyActionType {
	MOVE,
	DIG,
	YIELD,
}
